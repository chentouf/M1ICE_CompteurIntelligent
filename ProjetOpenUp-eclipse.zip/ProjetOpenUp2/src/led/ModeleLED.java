/*********************************************************************
	Rhapsody	: 8.1.3
	Login		: S219
	Component	: DefaultComponent
	Configuration 	: DefaultConfig
	Model Element	: ModeleLED
//!	Generated Date	: Fri, 20, Nov 2015 
	File Path	: DefaultComponent/DefaultConfig/LED/ModeleLED.java
*********************************************************************/

package led;

import java.util.Observable;

//## class ModeleLED

//----------------------------------------------------------------------------
// LED/ModeleLED.java                                                                  
//----------------------------------------------------------------------------

//## package LED 


//## class ModeleLED 
public class ModeleLED extends Observable {
    
    
    // Constructors
    
    //## auto_generated 
    public  ModeleLED() {
    }
    
}
/*********************************************************************
	File Path	: DefaultComponent/DefaultConfig/LED/ModeleLED.java
*********************************************************************/

