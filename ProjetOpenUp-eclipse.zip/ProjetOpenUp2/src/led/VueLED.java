/*********************************************************************
	Rhapsody	: 8.1.3
	Login		: S219
	Component	: DefaultComponent
	Configuration 	: DefaultConfig
	Model Element	: VueLED
//!	Generated Date	: Fri, 20, Nov 2015 
	File Path	: DefaultComponent/DefaultConfig/LED/VueLED.java
*********************************************************************/

package led;

import java.util.Observable;
import java.util.Observer;

//## class VueLED 

//----------------------------------------------------------------------------
// LED/VueLED.java                                                                  
//----------------------------------------------------------------------------

//## package LED 


//## class VueLED 
public class VueLED implements Observer {
    
    
    // Constructors
    
    //## auto_generated 
    public  VueLED() {
    }

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		
	}
    
}
/*********************************************************************
	File Path	: DefaultComponent/DefaultConfig/LED/VueLED.java
*********************************************************************/

