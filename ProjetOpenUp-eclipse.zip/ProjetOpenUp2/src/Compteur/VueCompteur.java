/*********************************************************************
	Rhapsody	: 8.1.3
	Login		: S219
	Component	: DefaultComponent
	Configuration 	: DefaultConfig
	Model Element	: VueCompteur
//!	Generated Date	: Fri, 20, Nov 2015 
	File Path	: DefaultComponent/DefaultConfig/Compteur/VueCompteur.java
*********************************************************************/

package Compteur;

import java.util.Observable;
import java.util.Observer;

//## class VueCompteur 
//----------------------------------------------------------------------------
// Compteur/VueCompteur.java                                                                  
//----------------------------------------------------------------------------

//## package Compteur 


//## class VueCompteur 
public class VueCompteur implements Observer {
    
    
    // Constructors
    
    //## auto_generated 
    public  VueCompteur() {
    }

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		
	}
    
}
/*********************************************************************
	File Path	: DefaultComponent/DefaultConfig/Compteur/VueCompteur.java
*********************************************************************/

