/*********************************************************************
	Rhapsody	: 8.1.3
	Login		: S219
	Component	: DefaultComponent
	Configuration 	: DefaultConfig
	Model Element	: ModeleLCD
//!	Generated Date	: Fri, 20, Nov 2015 
	File Path	: DefaultComponent/DefaultConfig/LCD/ModeleLCD.java
*********************************************************************/

package lcd;

import java.util.Observable;

//## class ModeleLCD 

//----------------------------------------------------------------------------
// LCD/ModeleLCD.java                                                                  
//----------------------------------------------------------------------------

//## package LCD 


//## class ModeleLCD 
public class ModeleLCD extends Observable {
    
    
    // Constructors
    
    //## auto_generated 
    public  ModeleLCD() {
    }
    
}
/*********************************************************************
	File Path	: DefaultComponent/DefaultConfig/LCD/ModeleLCD.java
*********************************************************************/

