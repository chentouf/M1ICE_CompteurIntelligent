/*********************************************************************
	Rhapsody	: 8.1.3
	Login		: S219
	Component	: DefaultComponent
	Configuration 	: DefaultConfig
	Model Element	: VueLCD
//!	Generated Date	: Fri, 20, Nov 2015 
	File Path	: DefaultComponent/DefaultConfig/LCD/VueLCD.java
*********************************************************************/

package lcd;

import java.util.Observable;
import java.util.Observer;

//## class VueLCD 
//----------------------------------------------------------------------------
// LCD/VueLCD.java                                                                  
//----------------------------------------------------------------------------

//## package LCD 


//## class VueLCD 
public class VueLCD implements Observer {
    
    
    // Constructors
    
    //## auto_generated 
    public  VueLCD() {
    }

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		
	}
    
}
/*********************************************************************
	File Path	: DefaultComponent/DefaultConfig/LCD/VueLCD.java
*********************************************************************/

